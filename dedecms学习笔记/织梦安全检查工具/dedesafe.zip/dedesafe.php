<?php
/*-------------------------------------------------------------------------------
织梦DedeCMS网站安全检测工具（by:tianya）

放置到网站根目录，在浏览器中打开对应地址访问即可
*/
error_reporting(0);
define(DEDEROOT, dirname(__file__));
define(DEDEDATA, DEDEROOT.'/data');
define(DEDEINC, DEDEROOT.'/include');
$signArr = array(
    'r' => '可读',
    'w' => '可写',
    'e' => '可执行'
);
//--------------------------------------------------------
// Need Function
//--------------------------------------------------------
/*
检测目录是否有写入权限
*/
function TestWriteable($d, $c=false)
{
    $tfile = '_write_able.txt';
    $d = preg_replace("/\/$/", '', $d);
    $fp = @fopen($d.'/'.$tfile,'w');
    if(!$fp)
    {
        if( $c==false )
        {
            @chmod($d, 0777);
            return false;
        }
        else return TestWriteable($d, true);
    }
    else
    {
        fclose($fp);
        return @unlink($d.'/'.$tfile) ? true : false;
    }
}

// 检查是否具目录可执行
function TestExecuteable($d='.', $siteuRL='', $rootDir='') {
    $testStr = '<'.chr(0x3F).'p'.chr(hexdec(68)).chr(112)."\n\r";
    $filename = md5($d).'.php';
    $testStr .= 'function test(){ echo md5(\''.$d.'\');}'."\n\rtest();\n\r";
    $testStr .= chr(0x3F).'>';
    $reval = false;
    if(empty($rootDir)) $rootDir = dirname(__file__);
    if (TestWriteable($d)) 
    {
        @file_put_contents($d.'/'.$filename, $testStr);
        $remoteUrl = $siteuRL.'/'.str_replace($rootDir, '', realpath($d)).'/'.$filename;
        $tempStr = @PostHost($remoteUrl);
        $reval = (md5($d) == trim($tempStr))? true : false;
        unlink($d.'/'.$filename);
        return $reval;
    } else
    {
        return '?';
    }
}

// 获取读写标记
function GetSign($key) {
    global $signArr;
    $reval = '';
    $key = explode(',', $key);
    foreach ($key as $v) {
        $reval .= isset($signArr[$v])? $signArr[$v].' ' : '';
    }
    return $reval;
}

function PostHost($host,$data='',$method='GET',$showagent=null,$port=null,$timeout=30){
    $parse = @parse_url($host);
    if (empty($parse)) return false;
    if ((int)$port>0) {
        $parse['port'] = $port;
    } elseif (!$parse['port']) {
        $parse['port'] = '80';
    }
    $parse['host'] = str_replace(array('http://','https://'),array('','ssl://'),"$parse[scheme]://").$parse['host'];
    if (!$fp=@fsockopen($parse['host'],$parse['port'],$errnum,$errstr,$timeout)) {
        return false;
    }
    $method = strtoupper($method);
    $wlength = $wdata = $responseText = '';
    $parse['path'] = str_replace(array('\\','//'),'/',$parse['path'])."?$parse[query]";
    if ($method=='GET') {
        $separator = $parse['query'] ? '&' : '';
        substr($data,0,1)=='&' && $data = substr($data,1);
        $parse['path'] .= $separator.$data;
    } elseif ($method=='POST') {
        $wlength = "Content-length: ".strlen($data)."\r\n";
        $wdata = $data;
    }
    $write = "$method $parse[path] HTTP/1.0\r\nHost: $parse[host]\r\nContent-type: application/x-www-form-urlencoded\r\n{$wlength}Connection: close\r\n\r\n$wdata";
    @fwrite($fp,$write);
    while ($data = @fread($fp, 4096)) {
        $responseText .= $data;
    }
    @fclose($fp);
    empty($showagent) && $responseText = trim(stristr($responseText,"\r\n\r\n"),"\r\n");
    return $responseText;
}


//
function getSuggest($dirArr,$key){
	$f_notice = $dirArr;
	$f_res = strpos($f_notice,$key);
	$f_ok = "<span style='color:red'>[×]Off</span>";
	$f_ook = "<span style='color:green'>[√]On</span>";
	switch($key){
		case "r" :
			if(strpos($f_notice,'r') !== false){
				$f_ok = $f_ook;
			}
			break;
		case "w" :
			if(strpos($f_notice,'w') !== false){
				$f_ok = $f_ook;
			}
			break;
		case "e" :
			if(strpos($f_notice,'e') !== false){
				$f_ok = $f_ook;
			}
			break;
		case "?" :
			if(strpos($f_notice,'?') == '?'){
				$f_ok = $f_ok;
			}
			break;
	}
	return $f_ok;	
}

//--------------------------------------------------------
// Need class
//--------------------------------------------------------

// 获取服务器基本信息
class Server {
    const DEDEDBCFG = 'common.inc.php';
    
    // 服务器操作类
    protected $_link;
        
    // 服务器相关信息
    public $serverOS = '';
    public $serverType='';
    public $phpVersion='';
    public $mysqlVersion='';
    public $dbConfig=array();
    
    function __construct() {
        $this->serverOS = PHP_OS;
        $this->serverType = $_SERVER['SERVER_SOFTWARE'];
        $this->phpVersion = PHP_VERSION;
        
        // 获取MySQL相关的信息
        $varItem = array('cfg_dbhost', 'cfg_dbname', 'cfg_dbuser', 'cfg_dbpwd',
            'cfg_dbprefix', 'cfg_db_language');
        $config = $this->parseConfig($varItem, DEDEDATA.'/'.self::DEDEDBCFG, true);
        $this->dbConfig = &$config;
        
        if (function_exists('mysql_connect')) 
        {
            $this->_link = @mysql_connect($config['cfg_dbhost'],$config['cfg_dbuser'],
            $config['cfg_dbpwd']);
            @mysql_select_db($config['cfg_dbname']);
            $rs = @mysql_query("SELECT VERSION();", $this->_link);
            $row = @mysql_fetch_array($rs);
            $mysql_version = $row[0];
            @mysql_free_result($rs);
            $mysql_versions = explode(".",trim($mysql_version));
            $this->mysqlVersion = number_format($mysql_versions[0].".".$mysql_versions[1],2);
        }
        
    }
    
    public function SetQuery($sql='') {
        return str_replace('#@__', $this->dbConfig['cfg_dbprefix'], $sql);
    }
    
    // 获取当前实例化对象的方法
    public static function getInstance($class = __CLASS__)
    {
        static $instances;

        if (!isset($instances)) {
            $instances = array();
        }
        if (empty($instances[$class])) {
            $instances[$class] = new $class;
        }
        return $instances[$class];
    }
    
    // 解析一个文件的配置函数
    public function parseConfig($valItem = array(), $configStr='', $isFile=false)
    {
        $reval = array();
        if($isFile) $configStr = file_get_contents($configStr);
        if(count($valItem) > 0)
        {
            $val = '('.implode('|', $valItem).')';
            // 通过正则取出DedeCMS程序基本配置
            preg_match_all('#'.$val.'[| ]=[| ][\'|"|](.*?)[\'|"|];#', $configStr, $matches);
            foreach ($matches[2] as $key=>$val) {
                $reval[$valItem[$key]] = isset($val)? $val : '';
            }
            return $reval;
        }
        return false;
    }
}

// 当前Dede站点的基本信息
class DedeSite extends Server
{
    const DEDEINC = 'common.inc.php';
    const DEDECFG = 'config.cache.inc.php';
    const UPDATEHOST = 'http://updatenew.dedecms.com';
    
    // 系统相关信息
    public $dedeVersion = '';
    public $dedeLang = 'gb2312';
    public $baseHost = '';
    public $cmsPath = '';
    public $dfStyle = '';
    public $updateHost = '';
    public $typeDirArr = array();
    
    function __construct() {
        parent::__construct();
        $this->parseDede();
    }
    
    // 解析Dede系统
    public function parseDede() {
        $valItem = array('cfg_version', 'cfg_soft_lang');
        
        $config = parent::parseConfig($valItem, DEDEINC.'/'.self::DEDEINC, true);
        $this->dedeVersion = $config['cfg_version'];
        $this->dedeLang = $config['cfg_soft_lang'];
        
        // 确定站点域名和
        $varItem = array('cfg_basehost', 'cfg_cmspath', 'cfg_df_style');
        $config = $this->parseConfig($varItem, DEDEDATA.'/'.self::DEDECFG, true);
        $this->baseHost = $config['cfg_basehost'];
        $this->cmsPath = $config['cfg_cmspath'];
        $this->dfStyle = $config['cfg_df_style'];
        preg_match("#v([0-9]{1,})_#i", $this->dedeVersion, $matches);
        $this->updateHost = self::UPDATEHOST.'/base-v'.$matches[1];
        //var_dump($config);
        
        $d = dir(DEDEROOT);
        $igdirs = array('a', 'data', 'plus', 'include', 'dede', 'images', 'member',
        'special', 'uploads','dede','templets','install');
        while (false !== ($entry = $d->read())) {
            if($entry != '.' && $entry != '..' && $entry != '.svn' && !in_array($entry, $igdirs) && is_dir($entry)) { 
                $this->typeDirArr[$this->cmsPath.'/'.$entry] = array('suggest'=> '?');
            }
        }
        // 查询栏目表确定栏目所在的目录
        $sql = "SELECT typedir FROM #@__arctype ORDER BY id DESC";
        $sql = $this->SetQuery($sql);
        $result = mysql_query($sql, $this->_link);

        while ($row = mysql_fetch_array($result, MYSQL_BOTH)) 
        {
            $row['typedir'] = str_replace("\\", '/', $row['typedir']);
            if(preg_match("/^http:|^ftp:/i", $row['typedir'])) continue;
            $typedir = str_replace("{cmspath}", $this->cmsPath, $row['typedir']);
            // 仅对某些版本处理
            //$typedir = str_replace("{areapath}", 'shanghai', $typedir);
            $typedir = str_replace($this->cmsPath, '', $typedir);
            $typearr = explode('/', $typedir);
            $this->typeDirArr[$this->cmsPath.'/'.$typearr[1]]['suggest'] = 'w,r';
        }
        @mysql_free_result($result);
    }
    
    // 检测默认的管理文件夹是否改名
    public function TestAdminCP() 
    {
        return file_exists(DEDEROOT.'/dede/archives_do.php');
    }
    
    // 检测用户名密码是否更改
    // 返回结果，-1：没有更改默认管理员名称  -2：没有更改默认管理员用户名和密码 0：没有发现默认账号
    public function TestAdminPWD() {
        $result = 0;
        // 查询栏目表确定栏目所在的目录
        $sql = "SELECT usertype,userid,pwd FROM #@__admin ORDER BY id DESC";
        $sql = $this->SetQuery($sql);
        $rs = mysql_query($sql, $this->_link);
        while ($row = mysql_fetch_array($rs, MYSQL_BOTH)) 
        {
            if($row['userid'] == 'admin')
            {
                $result = -1;
                if($row['pwd'] == 'f297a57a5a743894a0e4') $result = -2;
            }else{
				$result = -3;
			}
        }
        @mysql_free_result($result);
        return $result;
    }
    
    // 检测是否安装最新的补丁
    public function TestPath() 
    {
        //当前软件版本锁定文件
        $verLockFile = DEDEDATA.'/admin/ver.txt';
        $fp = fopen(realpath($verLockFile),'r');
        $upTime = trim(fread($fp,64));
        fclose($fp);
        $oktime = substr($upTime,0,4).'-'.substr($upTime,4,2).'-'.substr($upTime,6,2);
        $verlist = PostHost($this->updateHost.'/verinfo.txt');
        if($this->dedeLang == 'utf-8')
        {
            $verlist = iconv('gbk', 'utf-8//ignore', $verlist);
        }
        
        $verlist = preg_replace("#[\r\n]{1,}#", "\n", $verlist);
        $verlists = explode("\n", $verlist);
        //分析数据
        $updateVers = array();
		
        $upitems = $lastTime = '';
        $n = 0;
        foreach($verlists as $verstr)
        {
            if( empty($verstr) || preg_match("#^\/\/#", $verstr) ) 
            {
                continue ;
            }
            list($vtime, $vlang, $issafe, $vmsg) = explode(',', $verstr);
            $vtime = trim($vtime);
            $vlang = trim($vlang);
            $issafe = trim($issafe);
            $vmsg = trim($vmsg);
			
            if($vtime > $upTime && $vlang==$this->dedeLang)
            {
                $updateVers[$n]['issafe'] = $issafe;
                $updateVers[$n]['vmsg'] = $vmsg;
                $upitems .= ($upitems=='' ? $vtime : ','.$vtime);
                $lastTime = $vtime;
                $updateVers[$n]['vtime'] = substr($vtime,0,4).'-'.substr($vtime,4,2).'-'.substr($vtime,6,2);
                $n++;
            }
        }
        return $updateVers;
    }
    
    // 检查根目录下的Dir
    /*
               read读取(r)     write写入(w)     execute执行(e)        suggest系统建议
    include       true           true             false                   r,w,e
    plus          true           false             ?                    w,e
    .....         ...             ...              ...                     ...
    */
    public function TestDirs() 
    {
        $dirArr[$this->cmsPath.'/include'] = array('suggest'=>'r,e','remark'=>'类库文件目录');
        $dirArr[$this->cmsPath.'/plus'] = array('suggest'=>'r,e','remark'=>'辅助程序目录');
        $dirArr[$this->cmsPath.'/special'] = array('suggest'=>'r,e','remark'=>'专题目录[生成一次专题后可以删除]');
        $dirArr[$this->cmsPath.'/images'] = array('suggest'=>'r','remark'=>'系统默认模板图片存放目录');
        $dirArr[$this->cmsPath.'/member'] = array('suggest'=>'r,e','remark'=>'会员目录');
        $dirArr[$this->cmsPath.'/data'] = array('suggest'=>'r,w','remark'=>'系统缓存或其它可写入数据存放目录<br>[必须可写入]');
        $dirArr[$this->cmsPath.'/uploads'] = array('suggest'=>'r,w','remark'=>'默认上传目录[必须可写入]');
        $dirArr[$this->cmsPath.'/templets'] = array('suggest'=>'r','remark'=>'系统默认内核模板目录');
        $dirArr[$this->cmsPath.'/install'] = array('suggest'=>'','remark'=>'安装程序目录，安装完后建议删除<br>[安装时必须有可写入权限]');
        $dirArr[$this->cmsPath.'/dede'] = array('suggest'=>'r,e','remark'=>'默认后台管理目录（可任意改名）');
        $dirArr = array_merge($dirArr, $this->typeDirArr);
        

        foreach ($dirArr as $key => $val) 
        {
            $filename = DEDEROOT.'/'.$key;
            $dirArr[$key]['read'] = is_readable($filename);
            $dirArr[$key]['write'] = TestWriteable($filename);
            $dirArr[$key]['execute'] = TestExecuteable($filename, $this->baseHost);
        }
        return $dirArr;
    }
    
    // 站点的工厂类方法
    public static function getInstance($class = __CLASS__)
    {
        return parent::getInstance($class);
    }
}

$sv = DedeSite::getInstance();


$dopost = isset($_GET['dopost'])? $_GET['dopost'] : '';
$filename = 'all.png';
if($dopost == 'show')
{
   $img['all.png']='iVBORw0KGgoAAAANSUhEUgAAARgAAAC5CAMAAADEZ9BBAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ
bWFnZVJlYWR5ccllPAAAAwBQTFRFkb00vby9m8RFhLo6gLg2rKysfLUyhLcVbJwng7Itd7Iue3p7
/8UN/4kA56UCoqKi9YR4q9FXepzF2JEAfrEbioqK2mZcylVM/+dX4psBgICA/9c1u0Q7p81RoclL
hYWFjY2Oaoy1xE5FsrKyY4Wu/6UAlZWVi7opc6Mq/ZkA/pEA/qEAt9hqjY5yosw4fag4tD01WXul
i79AqzMrfKorlb1Egas3kZGRjboxmpqabqAoeq0i/60AlcA0Q2aR/9Mr/7EAi7Y08aIAeHqGzrsa
msU1/6gAiLwOfJNRnp6ekJellcMsfbAmrZhui7Q70ZcugrQn/7UAdqojptA5r9Ndnskz/7oB8ZsA
/8gklcA7ioqW/7ge0b8tzM0xfrc05bUTcKYjkL4qiLI2iLUvh7w8gK4smcQ7i5GdlJ2Fh7gonsk5
+aAA/70LiqtNt5gO4eHheaUrfYORib4//8g15LQrhYKMt5dNq60Zi6JY76gBf7Ar75MAlrpXjrRF
wI4vnqGV/rQL+qQAhrA5668F07FAqtI/naiIjb0fx5xHg7cglZ2K78gloZ2plcs7/q0NiIiHdacp
9bwRmIVhsNZLwcHBk5OX/9xAusQr/q4Fk46copiE+KkA9KIMlpmf+LQDj8EQlqxolJSUfrosfYB1
/7IDgoKC/K8BfKIg7qsK/7UE+LAEgoaQmZWfg3+NkLo/j5Sb9/f3+Pj49vb2+fn58/Pz+vr6+/v7
9PT08vLy8PDw8fHx9fX1/Pz87+/v7u7u/v7+/v/+7e3t///+grk4ebMwerQxiL091WFX6HVqzlpQ
dJe/3mtgUHOd0l1TU3agVXiiXH+oTG6ZZoixbY+44W5jSWyW5HJn63ltv0lATnGbcJK7cpS9X4Gr
rzcw7nxwR2qU8X90d5nBpi0mfqDIQGKNhbs7////h4eHZZgkl5eXkK5c/7ATn7cio6Cpp6enh7Ij
ksE3oNE+jY+B+LYKh4iKYpIlfq4z7cgwhJ8f+agH/6ICjbc4YqId/f39AAAAAAAA5GiYHQAAAQB0
Uk5T////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////AFP3ByUAABHFSURBVHja7N0JXJvnfcDxF1bV
qMLSGGgr8oS0MQmEYtg6QCezwEGOYhtL2CBwlgJWbY8jiV3PScBHDI6bssQRzkGcuGkq1/KcxMG9
78N1m+6+7/tsZLWLSprEW0Tqd//neKVX8MoC9xVG9Pl9Yn8SQC/WN//3eV+9L2COv6nKdvCrPO6m
HrUDYjCSLDtWuw239J0oXVkZgxFYqMttt612Gm7pLGWIpQz9KoN/yvQ/9TCAUEZZhjYPtOgxTdnN
0fyXXGVs9WflaikweoIALGXtmze3twwMtFTtoDT6pdL8nHzlwwXJLBJGrxdY9C0Dm1va21taOK7G
Xoxo9EhGf4tcRDL/LmeLg9ETF1Co4mpaIICZ5aCammLYu/S4qsXD/Iecpbb6r3K2GBjyvPWw0hbb
awZaKAyHsw8O9up3lC2N5g/ljW717+QtJ0yVwKLvtdfYwQLDEBc7yj/IVVGaqsXR/JO80a3+vrzl
gKmqwjCwivSGQjV2BINkOPvukJ3ChEJKpb0KrTNVqOLcMP8ob3SrfytvN4Qpxk8VWKpmlMpWzAAu
nD2E3oloCAzQ+FuL9WVEJjfNX8kb3epfy1t2mOJi6qIvntutDIVasQxYhFIfogwRF2hsS6hJL8jk
oPkleaNb/SN5ywbT1ERggCW0G7lQmZAy48OU1EWpVI5tUc5ULYomPzA/L29cdhYM07QLWOjTb22d
x4L3KCVxAZmxxjFMgx97A5q/lLflg5lpaqIDM7O7sRHBEBmRSnV1Jg12AZnOxo5iPZXJSvMr8ka3
+nvythBmZkaA6WjcByy7iYwygwWV/u/G3QQGPrRxampXsTA0vcsJ8yfyNh+mo2MGyxQ3dezbt6+x
sZHC7J7PMp8Gu8DHg8zURNMNaf5Z3uhW/0DeMmEmOjAMDMzEvlrsQkZGkgVSiGjQRzYSmdraa4Rm
z55eCZo/lze61V+QNzHMxASCmZtpOtJc6wSXlEz6QxTEo/qpp6oV82mmKAvK6WwGmj29xSCzgObX
5C3fMM3NE1gGsZRgFiojYlEILIpE0VP43yERzRSFqa2tdTobZqqwywKa/MD8srwJMA0NzdBEx5Ej
Dc6SEnhiAo2YhcAUFSniNqNNU11EYMQ0tVMCTC1sZt8RWGVwnHgy/0ze8gnT0IBhJoClpKTE6UzB
ZLIgmaKiRMQYMZsjRqMPaBQLaGqJC4wMEgaaPbMgMyuamj+VN7rVv5c3jrA0I5iJexpKrmIYIlMr
wVKtsSEWgAEarUMh0CR4sQ1xga5erSVTw4n2qD+WN7rVX5Q3jj9Cx6VhouHtt5GLMDLpZ5pIsfiM
Wps5ggYmErHZbFqtWUH3p0RCZOOkLrCtq287Z3rRVa1Zbra4Cb/3H+QtXzCPtBxpJitM8z74P0xk
RCo8PGWyvCgcRq3RZgMTJGNDGbXaSALRJFAaEQ2Bge1NhfDFCsQyQd73F/JGP+OvyhvsSpte2Exp
JiaanWhncmayIJnq6oRZi1ggYIHfsAukDRs1QJNYQFOCttVoR1eH7fbZpplr/fQ9fyNveYNZs2nT
CwMdzeSwNAHHahGLhjzf6mpNJKxFDDYyKEYeIRlJ2pjRBzODP1YjokmztPQCS3+n8I5/k7PUp/sX
OcPXfDdBLzwyN4Fhdu3alVKB8LgofMZYjCogFvJurTGVNqZ1JIShSdNwLfgSaEvvHGJJufC/IWep
rf66nGGYNZtSNBNYBtP4fBoso0g4jIaYSCE9EmHhrVptzKCNIxr8GB9VQS4tvb1zjYhFBMPnw0VW
GXpfaRPtEfsElQl9/6HHHvPhgXFoDWGtNkWQeRJLwLSosMEQ0SiwzOuPfaSFtqe3tRFUXK5Ol/hx
/y1XGX+a/5Qr4U7k5KYUTagDw7S2HvnEQ4+9ntCYDVEDft5aCRYUvJfAwNREDTagBJbDvQJLqLMf
VFyuLS5XId67Flxgp1oT6uhAMKGajk889OxBXTQWDofpM08/bN06EU2MTEw4Fjboojt9HzmM7+G2
tO+ZVXaiYXFtQRXmTX0BBjfY2tHR2tpqr5l7cP3BgwYKExazTE8voAGY2MFXouuPtG9uR2EWilK4
MGvIvKxZI9DMdczNzdkHMM1bQGMQs6ybxjJiGgMM1sFXDOuPdHVJshSaS/oW7ZrUwKAq/K1zKG6A
uwdNTfoBG9aJ2pB+ezT6iuHBpi7sMtTOIRZK4q+oKDiWjK92aJ5M01RUEBo4C9nM3ZPJAr+m3//+
aSIjokmxDHFKlyvNMnZPYX/h0M6dP3rwhwJNRQWm4egt2RbKgl02AMuBu6aBZgOOPr4LswwRFori
nwSW37p48enChcEHZKAZJDQVJL9doJlFLDjE4ja5vYhmQ4pmCNXVBSxjlMW/xT85qfz+71y8GI/D
i6uChKFH47Dt4rO6OxrTLhUVLr+dnpK0PHM3YZm+K2lxuwMBoIElGL3t0bvriUu9MC1+1OTk7js+
+ezrmji6fGOOxwsOJkZPU4xmW1Sl2qhCNCmYTpdyjtDMznbdDYeju5JWq9ft9kBe0w8OTK8DlpND
IFNPWTCKfxCzbNyo0tl8PgITN6+kJ16UpTSMGV4CIpqwUavCAc2+9Mi4OjuVXO8eQlP/mx+zmtwm
kxfDeNxeax+w1OOGepWCin9w0H8NWMj2VHhizBFz3OdbOSzfypJAw/EGmBQtOXmN6VI0AosLyXSO
zexpJ19g1nX7Ba+XwLjd7r5n6oewyomq3rHUsADL5B0qgcVgxBe3bHGfQ7tiXL5xg4qEXUkVhT+5
lrxQDBMa9J5OlyDjgtc714AGdfJk1+3Hk1aTF2D6nnnjjTe2ExalmMWPHk9YYjZ8DdRodpjDqoJw
oTIAAwuLTouu32IabTT15+93dbpcAk3/tabiIYHmAs8P9z2zHVi2128/oe/1w3qLQEDlLGHBNLpw
JI6v9JkdNgN8lhUD8/UbJsDwOp1OpYvhC7gZF1y6+x4gr43RxRRMU1Xf1Q6H5JNDJ/n67aCyffuJ
JxELJhkcrBl81f8/t5cKjycXzW22uANWdfgkfAHCIBqD0Sa+GBXoHhkppTRYZqrf2YBouuB8BeYE
VOqBpclfQVQGa2rOngUWFGHBweHIiFlWDkzRl3NUJJzH6AiNKk2zc2tfdzeSKe27tx9ogKVzCmSc
DYf128EFw5x4sqxJCSw1WKXmrP+Bvp5S0sNPP01ZzEYw10UhvvBgDDqBJpq6hGlDNKUj71gswXt/
F12axPde+0sQzYn6LsLiF1gGEIvaZDpNWLaa8Z0nWHG1wBKNGgyGlQTzlRylYPioTqDRRenl/507
bVt/22ux1Fkwzbv9nejWK/wqKWk4XHbiyduAxT8JgwLDMjBwdvABtdfrHbda3ace3nrp0tP4lC6i
hU0iFVSen+11UfLB8DpxBkxjs+3duXWb1YIL3vt/TnKzfqrWWXK14fAOmBa0/yCVgcEfYhY4wUl+
7KPP3XmJnOnawmmVZYB57QrttZwwX8qRCCZDBq/DuL17t27DMFYrz5c40cCgu7fOq1fHJtH+Q1jQ
8TmJXRDLneg1oyNui2Ww5NuFv37lA7QrssLw/MaNG9M0Kkqzl9DQD6E0YFPiHxjAKgM1wmmLlbA8
H487MEtUYNm/f//B/C8c1698mJYb5nM5yoTh739CRIN3KHxytvfSc1tFNxedaGdyOmFcBgY2k2mh
bX3uzucdOJshPSz796+/fzlW1OtXvkuTGcaa9L6zTUyjojSRyKVLET6DBpaZQcwyln57/HkJljCw
fBSOboHlgPkQLTfMF3MkghkfH0dXE97Ztn7e1ESE87T0dt++CjT2TBZCEscswj4Ui728/0cPn4Lz
oUAg4Mk/zPdoMsKMj2OY5OmRQOXR+TsUPSWBRDQlNTVb5rM4HL4USywWe+vll9cfrfx4aSlygbrz
DfNtWm6Yr+aIwgwTFqvpzQuV5eWV5Uef0IltDDY4IYmQq3BpmkYxi8+XYiEosTBhQfWdKiUw+Z2a
61feQ5ML5vGXzgwjmGGvuhx36NDRJz6ZcfC2OQhNXOL6JKhgF40P1haigq57hZ/Ypm5DLkB9DMN4
PCOlpXmEufxB2uWcMJ/JEYFZazkNNFbUeCWlCR4V705w8AYaAhN3LGTxOXwaDdqJYmFAQRd23nr5
/so2NR6YyjPnyYXQkdJTF/hCguHXrq3znkc0JjinDyKYSnKhSTw1sYjDgWDQPpP6DCkVTQR2ophW
uKgeQ+/EKuoz9FrfiyNvjgbzuitdfi8tN8ynckRh6tYSmmTSBDSmYGXqQpOYRhU2+2BsyCorYnFo
Egn8JRHCnX/R3Vz1GXxl2O0JIJa2tvzCvEqTDQZGBtEk3egqN8qd3kYmTVzjIzMDNEhFAyyKRMSg
Sw2LmIV3e/C4eLq7X0Is4/k9Kl3+Di03zKdzJMDUrU3ReMlrQdNCmmgUrTWOhI/sTxoNGhdgSX8B
DbqaLmZxe7FMd+CltjZ85MszzPto8sGQkUE0VkxjgrwSNDpCo3EADYJJVMO0GML4C4fIl5ulH4TW
FbfX4wkAyzApz+cxl9+l5Yb5bI7SZ75rU1ng6WAYr5hGhVnoEcqnSDjMDp+iWhFJDYtx3k5ECwTO
UBU4HShEGLz+CjQmoEErjdudSUPHBk2NQqEoUsBOpKXTYtTGePHagufFEzh/hpjASbXJyq8cmM/n
SPRaaa04C16D8f/yhTRkrfFhFiO9ryBmwQuuJ8UCJkk8gKbChBHL1NXVwdQISexQmMaQZhEvLanO
j+NZISoZy/mth/lCjjKvx4hhgCZJYRasNVHME5ZicaPFVsRCRsWUzLtKXmEEGuxSh9calCnjxEal
wjI6HYgYjbb5LG78mihwfhyPCjnAJa08v8Jgvpaj+TCEpi6Vxer2LFiHKc0CFryuwMrSHXCb0Kxg
k6TVujws+YZBxycRjAVNzYJ1GNPMYwl0w6DA4Rl+M+FlxYRMrKbkst0sWgrMj3MkBQM0Ypg6ize1
DHtENCptBguAdJOjEWLBJtZl24mWCyZFg++b1B0adnsojEdEo8s4EoFMt+fFbrfJRFjQ0JhMPL/K
YAQaC234fIDCeNwLPpQcnAPnurvPUZbk8hyfbwkMzx9KuwSDwbbzgXNYxuvOpPEEyOvnkZHTJkSS
pCpJnl+lMMjGIqb5+IvnFpzz4UuWbvdI6cixpJUeim4NC7pFe5n2Wr5hBJpg0DIcPBQcfXPkGD1A
ucmw0Cu5PaXHrBY488cvPuFFkZW/FS3lpv5PDAM0h8jADA8H24Kjp0qPuSkNZQmM9PQ8nhTOcWFX
so7zK78cMkX38Yv4yYmHkMow+q0tGFSf6rnrtBe7dHcHPC+WAgtabPGJC6wvSb4gkgUGTQ0eGFSw
8sKjG3pOmxCM51zPhgM/sCbJef+t24duHQzPlyMaLNNWCTTremBqAj3TwGIlLxJR43zhVJTTZbE/
hLS8kri0jY5WVqofnT6AWJJWNCxW0/Kfzf3kMkXfzFIRcVn8j60trwy2nWlTq9WjanWl+n8PPG7B
J/9JfO4yzBdc6PsGJFSK7iMuS/lBx+UwNqNAMzoKNhay/6CsBciSxsnoPoFliT8au7ycqIyOHj+D
D0PoRXTBsty4Jf4wdZgaNaJRe9GOlDStVpab+XsJgOb4cfU4WmDGVy3Lzf2FDeWVx4/DMXo1s9zs
X/FRXjlu5Vd3NwfD33uIX+0w11mScVdYknEfYEnGfZglGfddlmTch1iScd9jScb9DEsy7tssyRhM
Npj3sCTjPsiSjHsvSzIGkw3mVZZk3HdYknHvY0nGYLLBvMuSjMEwGAbDYBgMg2EwDIbBrDaYyyzJ
2E39bDf1eZacXx/DYBgMi8EwGAbDYBgMg2EwDIbBrG6YIpZk3LdYknHfYEnGYLLBfJ0lGYPJBvNl
lmQMJhvMV1iSMZhsMF9iScZgssF8jiUZg8kG80WWZAwmG8xXWZIxmGwwn2FJxmCywXyKJRmDyQbz
aZZkDCYbzGdZkjGYbDCfZ0nGYLLBfIElGYPJBvM1lmQMJhvMj1mSMRgGw2AYDINhMAyGwTAYBvNT
AvNNlmQMJhsM+3aKLN9kwb4Bh32/0pL6fwEGAFtHZ9kA5NjgAAAAAElFTkSuQmCC
';
header( 'Content-Type: image/png' );
echo base64_decode($img['all.png']);
exit;
}
if($dopost == 'icon')
{
   $img['icon.png']='iVBORw0KGgoAAAANSUhEUgAAACwAAAAeCAMAAABg6AyVAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ
bWFnZVJlYWR5ccllPAAAAwBQTFRF7YFsJokbh7tu5vTjfLhlPW+duc3jTHyhrtegnNaR1ePypaVE
qtOaespsqsTkwtXqa7o0f6DEvtLlnLvdh7xPfbs4WZsd1GdMqsnbe6XRuZtMY4m17PH39K2i8aaZ
4uv1fL1m835h0uDtpYc4lsyFs9qlcsNjteGukXQk2uXzbsFh64p8Q3aVXYi1cZ3N8npfV7kt8JSB
mNKL7JOIvuO3ydnpNJkcVr0yVIxlorvY3en22O3T8fnv8YFibLZW5YV2jK04/P37aJXDs96qg6vX
cshn+LWi52VWInMZ9fj7XsA3hcNzms6K+biludXs4oNZodeU+KGItMzjcZgisk0mhooocJnG8Z2O
kbE9k8F0Yoq5a5S/a5nGfbYz5Y2Cd7IuZY++cbhaapfFbrRX4l1ShabK+LOf9YFi86WQf8txQYwc
KX8cbcRiRqsgZ5PB7p+U5GZbdcloc7Zb3Xxuu0coXpwxf4IgbpUeTJIcgbk3gLg2frc18Hde6mtY
73Vc7nJb621Z7G9a+7yogs52j85+6GhXerQx5WFUk6/P9ohqebMw8qieW4mkish3c7xf+tnT0F5N
6O72VI9Jc8FYmcqGttTc52tcy1U56IlfKHca6XdZT5sc55CE9INmnL7Mhsl4fcBoiMN1w9XntVQs
xtfs4XlVbKBzYIaxrtyloMmWttPiY6AztdHq5XJV33Fea7MuS4Vf3On5TZpAzmZBvUkqZq4tkLPW
lLTZl7jam7TTbJTBlL+Ngai8b75W97Kjm8WS4G5Qdbo2f7VJYZpR9JiDn509lceCXahHmceG8vb6
dZ/Qd6C2ulgwY69LsM/YabhPf6fTja/TiK3Y6oZ8ZI241XZMaJOxxmQ7S5Y8W5ovZI696XxnH20Z
f66BXKEd0N7ujrLKIH4bUKIizNzqeMBj7IVhTLMl6W5ezdzvtk0pVpFKUZ9BXJZOqb/ab8dk42BT
x1I0wlk0crEwzls9hLo6/v/+h7w8i79Ahbs7ib4/iL09///+grk4////AAAAYqIdZaz0YAAAApVJ
REFUeNpi+EcCYPhNAmD4TgJg+EkCYPhFAmD4RgJg+EECYPhCAmD4QwJgqKysFBXwMjcwEKiuhIAI
qRm2tv5SEVCuyMqpfn7n9osAmQxVVQe9JgesWBFwPnd9FQhwP2XISEvLuL30KJgbuWqjlaamFZcE
U1UVQ/VB8xZ1zuZmTvVes63V1dXctoZNgZ2dgU2GB44CuZFrrO7zXXIRXqIpzFTNEAtUy1vo6lrI
67zQ7FOsw1PDpvT0v38V9X21xR1iRSSslrgIy8vzSbJxPTjEILBXndf1XU6Omgmv8/FHsVIMQLWK
f//q19S5rVOO3c314sIpTyC4IMnPf5fBIICzMCdHS8vkL7ORD2Obf0agoqL+37919Y2Gxtfb5mkK
n9KTDxLyFErapnSa4dmKTFd1a6BaR6MFHA+7ZrnN1dev+fu3saH2udz0rh2aknoxSUEyEy3zwrii
GXJXZGba/LX566iSqMDxMH5tmmJNXX3/39pW92lyH+IvakomOTmdlN9161Y0VxRDLqeR2nybv19V
7BJVTmTHXw0/Ut/YEC7r7t6uPedM/B6l7UlOeQkJUVFRqY97GB6ddX7S523tY5dcpLop67/yun0N
ta1//7a/T+meoPF/GRt/WEKCjIyurjSbpQXDPTNv1b7ExGSgWhYPsf/Bm+2Bphobp6R0F78s/7/6
milbdFRHh+7yt0LspQz/ZzMyqaoosKiostyp+P//f+hne1ntgoLL3cUlZUDuYd1FQqlXpAXZhFhf
/Wf4D1T9egoPz7EbHiC1QNUfxefk58dNCCkDc9+wW5oqKZnuZJ30H6T4v1hWtofHzCyx/xBQrrF4
S0mIRjmUW2qhw8rKuuHmf4hiosGQVPyVBMBASsEIEGAAVjjC+1Oi95sAAAAASUVORK5CYII=
';
   header( 'Content-Type: image/png' );
	echo base64_decode($img['icon.png']);
	exit;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="author" content="天涯，Fanr" />
<title>织梦安全检测工具 V0.0.1</title>
<style>
@charset "utf-8";body{background-color:#F0F7F0;margin-top:0;text-align:center;font-size:12px;font-family:'Microsoft YaHei';}#wrap{width:825px;margin:0 auto;}.fl{float:left;}.mtb10{margin:10px 0;}.m1018{margin:10px;}.cf{clear:both;}table{font-size:12px;text-align:center;}#top{position:fixed;width:825px;z-index:100;}.right{float:right;}.right span{width:79px;height:27px;line-height:22px;}.right a{color:#FFF;text-decoration:none;}.right .bbs{background:url(dedesafe.php?dopost=show) -115px -11px;float:right;}.right .desdev{background:url(dedesafe.php?dopost=show) -201px -11px;float:right;margin-right:5px;}#tool_title h2{margin:0;padding-top:50px;font-size:35px;}#tool_title h2 span{font-size:14px;}#header{position:relative;padding-top:15px;margin-bottom:50px;height:100px;}#logo{background:url(dedesafe.php?dopost=show);width:110px;height:94px;float:left;position:absolute;left:150px;}#logo_bg{height:46px;float:left;position:relative;top:20px;left:190px;z-index:-1;line-height:50px;}#sysinfo{position:absolute;left:170px;top:125px;float:left;}#logo_bg div{float:left;}#logo_bg .logo_left{background:url(dedesafe.php?dopost=show) -243px -40px;width:10px;height:51px;}#logo_bg .logo_center{background:url(dedesafe.php?dopost=show) 0px -135px repeat-x;width:500px;height:51px;}#logo_bg .logo_right{background:url(dedesafe.php?dopost=show) -267px -40px;width:10px;height:51px;}#main{position:relative;margin-top:25px;}#main .title{width:824px;height:28px;position:relative;}#main .title div{float:left;text-align:left;line-height:28px;}#main .title .titles{margin-left:35px;color:#fff;font-size:14px;}#main .title_left{background:url(dedesafe.php?dopost=show) -200px -51px;width:5px;height:30px;}#main .title_center{background:url(dedesafe.php?dopost=show) 0px -94px repeat-x;width:810px;height:30px;}#main .title_center .notice_image01{background:url(dedesafe.php?dopost=icon) -133px -38px;width:14px;height:14px;position:absolute;top:7px;left:15px;}#main .title_center .notice_image02{background:url(dedesafe.php?dopost=icon) -162px -38px;width:14px;height:14px;position:absolute;top:7px;right:15px;}#main .title_right{background:url(dedesafe.php?dopost=show) -207px -51px;width:5px;height:30px;}#main .content{line-height:50px;text-align:left;text-indent:30px;}#lines{border-top:1px solid #047700;height:10px;margin-top:50px;}#footer{}#footer i{color:#047700;}#footer a{color:#047700;text-decoration:none;}
</style>
</head>

<body>
<div id="wrap">
	<!--Navigation-->
	<div id="top">
		<div class="right">
	    	<span class="bbs"><a href="http://bbs.dedecms.com">织梦论坛</a></span>
	        <span class="desdev"><a href="http://site.desdev.cn">建站中心</a></span>
	    </div>
        <div class="cf"></div>
	</div>
    <div id="tool_title">
		<h2>织梦安全检测工具 <span>V0.0.1</span></h2>
	</div>
    <!--Logo-->
	<div id="header">
    	<div id="logo"></div>
        <div id="logo_bg">
        	<div class="logo_left"></div>
            <div class="logo_center">体检得分：<span id="score"></span>分  体检结果:<span id="safelevel"></span>   共发现<span id="questions"></span>项问题</div>
            <div class="logo_right"></div>
        </div>
        <div id="sysinfo">当前系统服务器环境：<?php echo $sv->serverType."   MySQL/".$sv->mysqlVersion; ?>&nbsp;&nbsp;DedeCMS版本：<?php echo $sv->dedeVersion; ?></div>
        <div class="cf"></div>
    </div>
    <!--Main Content-->
	<div id="main">
    	<div class="ques1">
        	<div class="title">
        		<div class="title_left"></div>
           		<div class="title_center">
            		<span class="notice_image01"></span>
               		<span class="titles">安全第一步：后台管理目录dede是否更改？</span>
            		<span class="notice_image02"></span>
            	</div>
            	<div class="title_right"></div>
        	</div>
        	<div class="content q1">
            	<?php
					echo ($sv->TestAdminCP())? '<font class="err" color=red>[×]请尽快修改后台默认目录dede为其他目录名称，以便您的系统更安全</font>' : '<font color=green>[√]您已经修改了后台默认目录，能够抵御15%的攻击！</font>'
				?>
            </div>
        </div>
        
        <div class="ques2">
        	<div class="title">
        		<div class="title_left"></div>
           		<div class="title_center">
            		<span class="notice_image01"></span>
           		<span class="titles">安全第二步：目录文件夹权限设定</span><span class="notice_image02"></span></div>
            	<div class="title_right"></div>
        	</div>
        	<div class="content fl mtb10 m1018 q2">
            	<table width="784" border="0" cellpadding="0" cellspacing="1" bgcolor="#047700">
			      <tr>
				        <td width="110" height="25" align="center" bgcolor="#E3F1D1">目录</td>
		        <td width="130" height="25" align="center" bgcolor="#E3F1D1">可读 / 建议</td>
				        <td width="130" height="25" align="center" bgcolor="#E3F1D1">可写 / 建议</td>
				        <td width="130" height="25" align="center" bgcolor="#E3F1D1">执行 / 建议</td>
				        <td height="25" align="center" bgcolor="#E3F1D1">备注</td>
				    </tr>
				<?php
				$dirArr = $sv->TestDirs();
				foreach($dirArr as $key => $val)
				{
				?>
				    <tr>
				        <td width="110" height="23" bgcolor="#FFFFFF"><?php echo $key;?></td>
		            <td width="130" height="23" bgcolor="#FFFFFF"><?php echo $val['read']? '<span style="color:green">[√]On</span>' : '<span style="color:red">[×]Off</span>';?>&nbsp;/&nbsp;<?php echo getSuggest($dirArr[$key]['suggest'],"r"); ?></td>
				        <td width="130" height="23" bgcolor="#FFFFFF"><?php echo $val['write']? '<span style="color:green">[√]On</span>' : '<span style="color:red">[×]Off</span>';?>&nbsp;/&nbsp;<?php echo getSuggest($dirArr[$key]['suggest'],"w"); ?></td>
				        <td width="130" height="23" bgcolor="#FFFFFF"><?php echo $val['execute']? '<span style="color:green">[√]On</span>' : '<span style="color:red">[×]Off</span>';?>&nbsp;/&nbsp;<?php echo getSuggest($dirArr[$key]['suggest'],"e"); ?></td>
				        <td height="23" bgcolor="#FFFFFF"><?php echo $dirArr[$key]['remark']; ?></td>
				    </tr>
				<?php
				}
				?>
                </table>
      </div>
            <div class="cf"></div>
        </div>
        
        <div class="ques3">
        	<div class="title">
        		<div class="title_left"></div>
           		<div class="title_center">
            		<span class="notice_image01"></span>
               		<span class="titles">安全第三步：系统账号、密码是否安全？</span>
            		<span class="notice_image02"></span>
            	</div>
            	<div class="title_right"></div>
        	</div>
        	<div class="content q3">
            	<?php
					$rs = $sv->TestAdminPWD();
					switch($rs) {
						case -1:
							echo '<font class="err" color="red">[×]强烈建议默认管理员账号：admin 改成其他的名称！</font>';
						break;
						case -2:
							echo '<font class="err" color="red">[×]默认账号和密码都是admin，不修改很危险哦！</font>';
						break;
						case -3:
							echo '<font color="green">[√]您的账号和密码安全！</font>';
						break;
					}
				?>
            </div>
        </div>
        
        <div class="ques4">
        	<div class="title">
        		<div class="title_left"></div>
           		<div class="title_center">
            		<span class="notice_image01"></span>
               		<span class="titles">安全第四步：是否打上了最新的安全补丁？</span>
            		<span class="notice_image02"></span>
            	</div>
            	<div class="title_right"></div>
        	</div>
        	<div class="content q4">
            	<?php
                    $rs = $sv->TestPath();
					$rs = implode(',',$rs);
                    if (empty($rs)) {
                        echo '<font color="green">[√]您已安装了最新版本的DedeCMS！</font>';
                    }else{
						echo '<font class="err" color="red">[×]当前不是最新的版本，请打上最新的补丁！</font>';
					}
                ?>
            </div>
        </div>
        
        
    </div>
    
    <div id="lines"></div>
    
    <!--Copyright-->
	<div id="footer">
    	<p>Powered by DedeCMS<?php echo $sv->dedeVersion; ?> &copy; 2004-2011 DesDev Inc.&nbsp;&nbsp;本程序编写：天涯 、Fanr</p>
        <p>Copyright &copy; 2004-2011 <a href="http://dedecms.com">DEDECMS</a>. 织梦科技 版权所有</p>
    </div>
</div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script type="text/javascript">
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('$("a").E({\'F\':\'T\'});v a=z;v b=0;D m(c){$(c).M(\'.N\').h({\'O\':\'J(K.L?S=U) -P -Q\'})};i($(\'.R\').r().q("p")){a-=15;b+=1;m(".I")};i($(".C").r().q("p")){m(".B")};i($(".A").r().q("p")){a-=15;b+=1;m(".G")};i($(".H").r().q("p")){a-=15;b+=1;m(".13")};i(a==z){$("#f").e(" 12！");o=10}18{o=17(a/10);x(o){d 9:$("#f").e(" 16！");g;d 8:$("#f").e(" X！");g;d 7:$("#f").e(" w！");g;d 6:$("#f").e(" w！");g;d 5:$("#f").e(" W！");g;d 4:$("#f").e(" V！");g;d 3:$("#f").e(" 11！");g;d 2:$("#f").e(" Z！");g;d 1:$("#f").e(" Y！");g;d 0:$("#f").e(" 14！");g}};x(o){d 10:d 9:d 8:$("#f").h({\'n-l\':\'k\',\'j\':\'u\'});$("#t").h({\'n-l\':\'k\',\'j\':\'u\'});g;d 7:d 6:d 5:d 4:d 3:d 2:d 1:$("#f").h({\'n-l\':\'k\',\'j\':\'s\'});$("#t").h({\'n-l\':\'k\',\'j\':\'s\'});g};$("#t").e(" "+a+" ");$("#y").e(" "+b+" ");$("#y").h({\'n-l\':\'k\',\'j\':\'s\'});',62,71,'|||||||||||||case|html|safelevel|break|css|if|color|20px|size|change|font|tot|err|hasClass|children|red|score|green|var|风险|switch|questions|100|q3|ques2|q2|function|attr|target|ques3|q4|ques1|url|dedesafe|php|find|notice_image01|background|147px|39px|q1|dopost|_blank|icon|很有风险|有风险|一般|极其风险|相当风险||十分风险|非常安全|ques4|特别风险||较安全|parseInt|else'.split('|'),0,{}))
</script>
</body>
</html>
