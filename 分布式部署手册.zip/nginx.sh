mkdir /root/nginxphp/
cd /root/nginxphp/
tee run.sh << EOF
#!/bin/bash
/usr/sbin/sshd -D &
/usr/local/php/sbin/php-fpm -D &
exec /usr/local/nginx/sbin/nginx -g "daemon off;"
EOF
tee Dockerfile << EOF
FROM sshd1
MAINTAINER Ocean <http://blog.sina.com.cn/wxwangjiaen>
ADD run.sh /usr/local/src/run.sh
RUN chown root.root /usr/local/src/run.sh \
    && chmod +x /usr/local/src/run.sh
EXPOSE 80
CMD ["/usr/local/php/sbin/php-fpm","-D"]
CMD ["/usr/local/src/run.sh"]
EOF
docker build -t sshd1:v1 .
docker run -d --restart=always -p 80:80 sshd1:v1
