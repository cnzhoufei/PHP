//app.js
App({

  onLaunch: function() {
try {
  var value = wx.getStorageSync('session')
  if (value) {
    console.log(value)
    this.globalData.session = value;
  }
} catch (e) {
  // Do something when catch error
}
        
  },

 

  globalData: {
    session:null,
    userInfo: null,
    imgdomain: 'https://xiaochengxu.yundi88.com',//图片域名
    datadomain:'https://xiaochengxu.yundi88.com',//数据域名
    store_id:6,//商户id
    appid:'wx6ec733a93fa887c2',//小程序appid
    secret: '5af98fd04c2b9d6fb3022a09db50ff8b',//小程序的 app secret
  }
})
