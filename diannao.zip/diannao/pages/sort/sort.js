// sort.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgdomain: app.globalData.imgdomain,
    datadomain: app.globalData.datadomain,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(1111)
    var mythis = this;
    wx.request({
      url: app.globalData.datadomain + '/min/index/goodsclass/', //仅为示例，并非真实的接口地址
        data: {
          store_id: app.globalData.store_id,
        },
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          mythis.setData({ data: res.data, num: res.data.class[0].cat_id, child: res.data.child})
          // console.log(res.data)
        }
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  mylick: function (e) {
    var id = e.target.id;
    this.setData({ num: id });
    var mythis = this;
    wx.request({
      url: app.globalData.datadomain + '/min/index/goodsclass/', //仅为示例，并非真实的接口地址
      data: {
        store_id: app.globalData.store_id,
        pid: id
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        mythis.setData(
          {
            child: res.data.class,
          }
        )
      }
    })
  }
})