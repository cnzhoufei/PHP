// collection.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showView: false,
    data:null,
    imgdomain: app.globalData.imgdomain,
    quanxuancolor:'#E4E4E4',
  },

  onChangeShowState: function() {
    var that = this;
    that.setData({
      showView: (!that.data.showView)
    })
  },
    
  remove: function(){
    var mythis = this;
      var collectid = '';
      var data = this.data.data;
      for(var i = 0;i < data.length;i++){
        if(data[i].color=='#f00'){
          collectid += data[i].collect_id+',';
        }
      }

      wx.request({
        url: app.globalData.datadomain + '/min/Goods/deletecollect',
        data: {
          store_id: app.globalData.store_id,
          session: app.globalData.session,
          collectid:collectid,
        },
        success: function (res) {
          console.log(res)
          if (res.data.res.res == 1) {
            for (var i = 0; i < data.length; i++) {
              if (data[i].color == '#f00') {
                data.splice(i, 1);
              }
            }
            mythis.setData({
              data: data, msg: '你最近收藏了' + data.length + '款产品',
            })
            if(!data.length){
              mythis.setData({
                showView:false,data:null
              })
            }
           
           
            wx.showToast({
              icon: 'success_no_circle',
              title: '' + res.data.res.msg + '',
              duration: 2000
            });

          }else{
            wx.showToast({
              image: '../../images/error.png',
              title: ''+res.data.res.msg+'',
              duration: 2000
            });
              
          }

        }, fail: function () {
          wx.showToast({
            title: '网络请求超时！',
            image: '../../images/error.png',
            duration: 2000
          })
        }
      })
      


   
  },
  onShow:function(){
    var mythis = this;
    wx.request({
      url: app.globalData.datadomain + '/min/Goods/llectionlist',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
      },
      success: function (res) {
        // console.log(res)
        if(res.data.res.res == 1){
          mythis.setData({ data: res.data.data })

        }
        mythis.setData({msg:res.data.res.msg})

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })

  },
  //选择
  xuanze:function(e){
   var index = e.target.dataset.index;
    var data = this.data.data;
    for(var i =0;i<data.length;i++){
      if(i == index){
        var color = data[i].color == '#E4E4E4' ? '#f00' :'#E4E4E4';
        data[i].color = color;
      }
      this.setData({
        data:data,
      })
    }
// console.log(e)
  },
  //全选
  quanxuan:function(e){
    var quanxuancolor = this.data.quanxuancolor == '#E4E4E4' ? '#f00' : '#E4E4E4';
    var data = this.data.data;
    for(var i = 0;i<data.length;i++){
        data[i].color = quanxuancolor;
    }
    this.setData({
      data: data, quanxuancolor: quanxuancolor
    })
  }
})