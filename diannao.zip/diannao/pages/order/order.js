// order.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgdomain: app.globalData.imgdomain,
    datadomain: app.globalData.datadomain,
    p:1,
    data:[],
    msg:'',
    status:false,
    sql:'all',
    on:1
  },
  to_pay: function () {
    wx.navigateTo({
      url: '../pay/pay'
    })
  },
  remove: function (e) {
    var order_sn = e.target.dataset.index;
    var mythis = this;
    // 给出确认提示框
    wx.showModal({
      title: '提示',
      content: '确定删除该订单嘛？',
      success:function(res){
        if (res.confirm == true){
          //
          wx.request({
            url: app.globalData.datadomain + '/Min/Order/removeorder',
            data: {
              store_id: app.globalData.store_id,
              session: app.globalData.session,
              order_sn:order_sn
            },
            success: function (res) {
              if (res.data.res.res == 1) {

                mythis.onLoad()

              } else {
                wx.showToast({
                  title: '' + res.data.res.msg + '',
                  image: '../../images/error.png',
                  duration: 2000
                })
              }

            }, fail: function () {
              wx.showToast({
                title: '网络请求超时！',
                image: '../../images/error.png',
                duration: 2000
              })
            }

          })
        }
      }

    })
  },
  onLoad:function(e){
    console.log(e)
    // var on = e.field+e.status;
// return;
      this.setData({ sql: e.sql ? e.sql : this.data.sql,on:e.on})
      var sql = this.data.sql;
    var mythis = this;
    // var field = e.field;
    if (sql =='all'){
    wx.request({
      url: app.globalData.datadomain + '/Min/Order/orderlist',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        p:mythis.data.p
      },
      success: function (res) {
        if (res.data.res.res == 1) {

          if (res.data.data.length > 0) {
            var list = mythis.data.data;
            for (var i = 0; i < res.data.data.length; i++) {
              list.push(res.data.data[i]);
            }
            mythis.setData(
              {
                data: list,
              }
            )
          } else {
            mythis.setData({
              msg: p > 1 ? '没有了!' : '暂无数据!',
              status: true,
            })
          }

        //  mythis.setData({
        //    data:res.data.data
        //  })

        } else {
          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }

    })
  }else{


    wx.request({
      url: app.globalData.datadomain + '/Min/Order/order_status',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        p: mythis.data.p,
        sql:sql
      },
      success: function (res) {
        if (res.data.res.res == 1) {

          if (res.data.data.length > 0) {
            var list = mythis.data.data;
            for (var i = 0; i < res.data.data.length; i++) {
              list.push(res.data.data[i]);
            }
            mythis.setData(
              {
                data: list,
                // field:field,
              }
            )
          } else {
            mythis.setData({
              msg: p > 1 ? '没有了!' : '暂无数据!',
              status: true,
            })
          }

          //  mythis.setData({
          //    data:res.data.data
          //  })

        } else {
          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }

    })
     

  }
  },
  onReachBottom: function () {
this.setData({
  p:this.data.p+1
})
    var field = { 'field': this.data.field}
    this.onLoad(field)

  },
  shouhuo:function(e){
    var mythis = this;
    var order_sn = e.currentTarget.dataset.index;
    wx.showModal({
      title: '提示',
      content: '请确认收到商品后台在确认收货？',
      success: function (res) {
        if (res.confirm == true) {
                // 发起网络请求
                wx.request({
                  url: app.globalData.datadomain + '/min/Order/shouhuo',
                  data: {
                    store_id: app.globalData.store_id,
                    session: app.globalData.session,
                    order_sn:order_sn
                  },
                  success: function (res) {
                    if(res.data.res.res == 1){
                     
                      wx.redirectTo({
                        url: '/pages/order/order?sql=shipping_status eq 1 and pay_status eq 1 and order_status not in(2,3,4,5)&on=4'
                      })
                    }else{
                      wx.showToast({
                        title: ''+res.data.res.msg+'',
                        image: '../../images/error.png',
                        duration: 2000
                      })
                    }

                   
                  }, fail: function () {
                    wx.showToast({
                      title: '网络请求超时！',
                      image: '../../images/error.png',
                      duration: 2000
                    })
                  }
                })
        }
      }
    })
  }
})