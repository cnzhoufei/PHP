// search.js
var app = getApp()
Page({
  data: {
    imgdomain: app.globalData.imgdomain,
    showView: false,
    data: [],
     msg: '暂无数据',
     status:false,
    p:1
  },
  onLoad:function(options)
  {
    // console.log('p'+this.data.p)
    // console.log(options)
    var p = this.data.p;
    var mythis = this;
    //如果search不为真 就是就是搜索
    if(!options.search){
      var id = options.id;

        wx.request({
          url: app.globalData.datadomain + '/min/index/goodslist/', //仅为示例，并非真实的接口地址
          data: {
            store_id: app.globalData.store_id,
            cid: id,
            p:p
          },
          header: {
            'content-type': 'application/json'
          },
          success: function (res) {
            if (res.data.goodslist.length > 0) {
              var list = mythis.data.data;
              for (var i = 0; i < res.data.goodslist.length; i++) {
                list.push(res.data.goodslist[i]);
              }
              mythis.setData(
                {
                  data: list,
                  p: ++p
                }
              )
            } else {
              mythis.setData({
                msg: p > 1 ? '没有了！' : '暂无数据!',
                status: true,
              })
            }



          }
        })

    }else{
    var str = options.search;
      wx.request({
        url: app.globalData.datadomain + '/min/index/search/', //仅为示例，并非真实的接口地址
        data: {
          store_id: app.globalData.store_id,
          str: str,
        },
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          mythis.setData({ data: res.data })
        }
      })
    }
  },

  onReachBottom:function()
  {
    
    var i = {id:21}
    this.onLoad(i)
  }
  
  
  
  ,
  onChangeShowState: function () {
    var that = this;
    that.setData({
      showView:true
    })
  },
  onChangeHideState: function () {
    var that = this;
    that.setData({
      showView: false
    })
  },
})