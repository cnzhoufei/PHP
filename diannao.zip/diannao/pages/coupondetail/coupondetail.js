// coupondetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
  
  },
  success: function () {
    wx.showToast({
      icon: 'success_no_circle',
      title: '领取成功'
    });
  },
})