// addaddress.js
var address = require('../../utils/city.js')
var app = getApp()
var animation
Page({
  formSubmit: function (e) {
    var data = e;
    // name
    var name = e.detail.value.name;
    // detail
    var detail = e.detail.value.detail;
    // mobile
    var mobile = e.detail.value.mobile;
    
    if (name == '') {
      wx.showToast({
        title: '请填写收件人',
        image: '../../images/error.png',
        duration: 2000
      });
      return;
    }
    if (!(/^1[34578]\d{9}$/.test(mobile))) {
      wx.showToast({
        title: '请填写正确手机号码',
        image: '../../images/error.png',
        duration: 2000
      });
      return;
    }
    if (this.data.areaSelectedStr == '请选择') {
      wx.showToast({
        title: '请输入区域',
        image: '../../images/error.png',
        duration: 2000
      });
      return;
    }
    if (detail == '') {
      wx.showToast({
        title: '请填写详情地址',
        image: '../../images/error.png',
        duration: 2000
      });
      return;
    }
    //提交地址
    this.address(data)

   
  },
  address:function(data){
    // 发起网络请求
    wx.request({
      url: app.globalData.datadomain + '/min/Address/add',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        name: data.detail.value.name,//姓名
        mobile: data.detail.value.mobile,//手机
        address: data.detail.value.address,//地址
        detail: data.detail.value.detail,//地址
        address_id: data.detail.value.address_id,//地址
      },
      success: function (res) {

        wx.showToast({
          title: ''+res.data.res.msg+'',
          duration: 2000,
          success:function(res){
            wx.navigateBack(1);
          }
        });
      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })
  },


  /**
   * 页面的初始数据
   * 当前    provinces:所有省份
   * citys选择省对应的所有市,
   * areas选择市对应的所有区
   * provinces：当前被选中的省
   * city当前被选中的市
   * areas当前被选中的区
   */
  data: {
    animationAddressMenu: {},
    addressMenuIsShow: false,
    value: [0, 0, 0],
    provinces: [],
    citys: [],
    areas: [],
    province: '',
    city: '',
    area: '',
    areaSelectedStr:'请选择',
    address_id:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(options.id){
      this.onchange(options.id)
    }
    // 初始化动画变量
    var animation = wx.createAnimation({
      duration: 500,
      transformOrigin: "50% 50%",
      timingFunction: 'ease',
    })
    this.animation = animation;
    // 默认联动显示北京
    var id = address.provinces[0].id
    this.setData({
      provinces: address.provinces,
      citys: address.citys[id],
      areas: address.areas[address.citys[id][0].id],
    })
    // console.log(this.data)
  },
  // 点击所在地区弹出选择框
  selectDistrict: function (e) {
    var that = this
    // console.log('111111111')
    if (that.data.addressMenuIsShow) {
      return
    }
    that.startAddressAnimation(true)
  },
  // 执行动画
  startAddressAnimation: function (isShow) {
    // console.log(isShow)
    var that = this
    if (isShow) {
      that.animation.translateY(0 + 'vh').step()
    } else {
      that.animation.translateY(40 + 'vh').step()
    }
    that.setData({
      animationAddressMenu: that.animation.export(),
      addressMenuIsShow: isShow,
    })
  },
  // 点击地区选择取消按钮
  cityCancel: function (e) {
    this.startAddressAnimation(false)
  },
  // 点击地区选择确定按钮
  citySure: function (e) {
    var that = this
    var city = that.data.city
    var value = that.data.value
    that.startAddressAnimation(false)
    // 将选择的城市信息显示到输入框
    var areaInfo = that.data.provinces[value[0]].name + ',' + that.data.citys[value[1]].name + ',' + that.data.areas[value[2]].name
    that.setData({
      areaInfo: areaInfo,
      areaSelectedStr: areaInfo
    })
  },
  hideCitySelected: function (e) {
    // console.log(e)
    this.startAddressAnimation(false)
  },
  // 处理省市县联动逻辑
  cityChange: function (e) {
    // console.log(e)
    var value = e.detail.value
    var provinces = this.data.provinces
    var citys = this.data.citys
    var areas = this.data.areas
    var provinceNum = value[0]
    var cityNum = value[1]
    var countyNum = value[2]
    if (this.data.value[0] != provinceNum) {
      var id = provinces[provinceNum].id
      this.setData({
        value: [provinceNum, 0, 0],
        citys: address.citys[id],
        areas: address.areas[address.citys[id][0].id],
      })
    } else if (this.data.value[1] != cityNum) {
      var id = citys[cityNum].id
      this.setData({
        value: [provinceNum, cityNum, 0],
        areas: address.areas[citys[cityNum].id],
      })
    } else {
      this.setData({
        value: [provinceNum, cityNum, countyNum]
      })
    }
    // console.log(this.data)
  },
  //修改地址
  onchange:function(id){
    var mythis = this;
    // 发起网络请求
              wx.request({
                url: app.globalData.datadomain + '/min/Address/change',
                data: {
                  store_id: app.globalData.store_id,
                  id:id
                },
                success: function (res) {
                  if(res.data.res == 1){
                    mythis.setData({
                      areaSelectedStr: res.data.data.address2,
                      address: res.data.data.address1,
                      areaInfo: res.data.data.address2,
                      name: res.data.data.consignee,
                      mobile: res.data.data.mobile,
                      address_id: res.data.data.address_id,
                    })
                        
                  }else{
                      wx.showToast({
                        title: '地址不存在!',
                        image: '../../images/error.png',
                        duration: 2000
                      })
                  }
                }, fail: function () {
                  wx.showToast({
                    title: '网络请求超时！',
                    image: '../../images/error.png',
                    duration: 2000
                  })
                }
              })
  }
  
})
