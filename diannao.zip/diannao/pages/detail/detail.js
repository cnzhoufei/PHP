// detail.js
var app = getApp()
var R_htmlToWxml = require('../../utils/htmlToWxml.js');//引入公共方法
var R_util = require('../../utils/util.js');//引入公共方法
Page({
  data: {
    num:1,
    imgdomain: app.globalData.imgdomain,
    datadomain: app.globalData.datadomain,
    indicatorDots: false,
    autoplay: true,
    interval: 3000,
    duration: 500,
    tabs: ["图文详情", "产品参数", "相关推荐"],
    activeIndex: 0,
    actionSheetHidden1: true,
    actionSheetHidden2: true,
    actionSheetHidden3: true,
    actionSheetHidden4: true,
    actionSheet1Items: [
      {
        logo: "../../images/detail_true.png",
        text: "正品保证"
      },
      {
        logo: "../../images/detail_true.png",
        text: "七天退换货"
      },{
        logo: "../../images/detail_true.png",
        text: "保修"
      }
     
    ]
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options)
    var mythis = this;
    wx.request({
      url: app.globalData.datadomain + '/min/index/goods', //仅为示例，并非真实的接口地址
      data: {
        store_id: app.globalData.store_id,
        id: options.id,
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res)
        res.data.goods.goods_content = R_htmlToWxml.html2json(res.data.goods.goods_content);
        mythis.setData({ 
          data: res.data, //商品数据
          price: res.data.price.price,//默认的规格价格 
          items: res.data.items, //默认的规格key 加上了&&&
          keys:res.data.price.key,//默认的规格key 当前选择的
          store_count: res.data.price.store_count//
          
          })
      }
    })

  },
  //规格选择
  radioChange: function (e) {
    // console.log('radio发生change事件，携带value值为：', e)
    var items = e.detail.value + this.data.items;

    var mythis = this;
    wx.request({
      url: app.globalData.datadomain + '/min/index/price', //仅为示例，并非真实的接口地址
      data: {
        store_id: app.globalData.store_id,
        items: items,
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        mythis.setData({ 
          price: res.data.price.price,//价格
          items:items,//规格key
          store_count: res.data.price.store_count,//库存
          num:1,//商品数量归1 
          keys: res.data.price.key,//当前选中的规格key
          })
        var count = mythis.data.store_count;
          if (!count){
                wx.showToast({
                  title: '库存不足！',
                  image: '../../images/error.png',
                  duration: 2000
                })
          }
      }
    })

  },
  // 第一个弹窗
  action: function () {
    this.setData({
      actionSheetHidden1: false
    })
  },
  actionSheetChange: function () {
    this.setData({
      actionSheetHidden1: !this.data.actionSheetHidden1
    })
  },
  tabClick: function (e) {
    this.setData({
      activeIndex: e.currentTarget.id
    });
  },
   //加入购物车的弹出页面
  action2: function (e) {
    console.log(e)
    this.setData({
      anniu: e.target.dataset.index,//加入购物车按钮
      anniubg:'#'+e.target.dataset.bg,//按钮背景
      actionSheetHidden2: false,
    })
  },
  actionSheet2Change: function () {
    this.setData({
      actionSheetHidden2: !this.data.actionSheetHidden2
    })
  },
  //立即购买的弹出页面
  action3: function (e) {
    this.setData({
      actionSheetHidden3: false,
    })
  },
  actionSheet3Change: function () {
    this.setData({
      actionSheetHidden3: !this.data.actionSheetHidden3
    })
  },
  //立即购买的弹出页面
  action4: function (e) {
    this.setData({
      actionSheetHidden4: false,
    })
  },
  actionSheet4Change: function () {
    this.setData({
      actionSheetHidden4: !this.data.actionSheetHidden4
    })
  },

  addcart:function(e){

    wx.checkSession({
                  success: function () {
                    //session 未过期，并且在本生命周期一直有效
                    if (!wx.getStorageSync('session')){
                      wx.navigateTo({
                        url: '../login/index'
                      })
                    }
                  },
                  fail: function () {
                    wx.navigateTo({
                      url: '../login/index'
                    })
                  }
                })
    if (!app.globalData.userInfo) {
      wx.navigateTo({
        url: '../login/index'
      })
    }





    var mythis = this;
    if(this.data.store_count > 0){

      // console.log(this.data.keys)
      // console.log(this.data.num)
      // console.log(e.target.dataset.goods_id)


      //加入购物车
      wx.request({
        url: app.globalData.datadomain + '/min/goods/addsort',
        data: {
          store_id: app.globalData.store_id,
          session: app.globalData.session,
          spec_key: mythis.data.keys,
          goods_num: mythis.data.num,
          goods_id: e.target.dataset.goods_id,
        },
        success: function (res) {
          if (res.data.res.res == 1) {
            wx.showToast({
              title: '' + res.data.res.msg + '',
              duration: 2000
            })
          } else {

            wx.showToast({
              title: '' + res.data.res.msg + '',
              image: '../../images/error.png',
              duration: 2000
            })
          }



        }, fail: function () {
          wx.showToast({
            title: '网络请求超时！',
            image: '../../images/error.png',
            duration: 2000
          })
        }
      })









            this.setData({
              actionSheetHidden2: !this.data.actionSheetHidden2
            })

            wx.showToast({
              title: '加入成功',
              duration: 1000
            })
    }else{

      wx.showToast({
        title: '库存不足！',
        image: '../../images/error.png',
        duration: 2000
      })

    }
   
  },
  
  add:function(){
    if(this.data.num < this.data.store_count){
      this.setData({
        num: this.data.num + 1
      })
    }else{
      wx.showToast({
        title: '哎呀!此规格没有更多喽！',
        image:'../../images/error.png',
        duration: 2000
      })
    }
    
  },
  reduce:function(){

    if(this.data.num>1){
      this.setData({
        num:this.data.num - 1
      })
    }
  },
  collection:function(e){
    // console.log(e.currentTarget.id)
    
    if (app.globalData.session){
      var id = e.currentTarget.id;
      wx.request({
        url: app.globalData.datadomain + '/min/goods/goodscollection',
        data: {
          store_id: app.globalData.store_id,
          id: id,
          session: app.globalData.session
        },
        success: function (res) {
          console.log(res)
          if (res.data.res.res == 1) {
            wx.showToast({
              title: '' + res.data.res.msg + '',
              duration: 2000
            })
          } else {

            wx.showToast({
              title: '' + res.data.res.msg + '',
              image: '../../images/error.png',
              duration: 2000
            })
          }



        }, fail: function () {
          wx.showToast({
            title: '网络请求超时！',
            image: '../../images/error.png',
            duration: 2000
          })
        }
      })

    }else{

      wx.switchTab({
        url: '../user/user'
      })

    }
    
  }
  
});
