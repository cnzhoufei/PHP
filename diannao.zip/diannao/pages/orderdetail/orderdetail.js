// orderdetail.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgdomain: app.globalData.imgdomain,
    datadomain: app.globalData.datadomain,
    actionSheetHidden1: true,
    defaultaddress: { address_id:0},
    msg:null
  },
  // 第一个弹窗
  action: function () {
    var mythis = this;
    wx.request({
      url: app.globalData.datadomain + '/min/Cart/address',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
      },
      success: function (res) {
        if (res.data.res.res == 1) {
          // console.log(res)
          mythis.setData({
            actionSheetHidden1: false,
            address: res.data.address,
          })
        } else {
          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })
   
  },
  actionSheetChange: function (e) {
    var mythis = this;
    var index = e.currentTarget.dataset.index
    var address = this.data.address;
    mythis.setData({
      defaultaddress:address[index],
    })
    this.setData({
      actionSheetHidden1: !this.data.actionSheetHidden1
    })
  },
  onLoad:function(options){
    var mythis = this;
    var id = options.id;
    wx.request({
      url: app.globalData.datadomain + '/min/Cart/index',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        id:id,
      },
      success: function (res) {
        if (res.data.res.res == 1) {
          mythis.setData({
            cart:res.data.cart,
            total: res.data.total,
            defaultaddress: res.data.defaultaddress,
          })
        }else{
          wx.showToast({
            title: ''+res.data.res.msg+'',
            image: '../../images/error.png',
            duration: 2000
          })
        }

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })
  },
  // 提交订单
  mysubmit:function()
  {
    var mythis = this;
    var address_id = this.data.defaultaddress.address_id;//地址id
    if (address_id == 0) {
      wx.showToast({
        title: '地址不能为空！',
        image: '../../images/error.png',
        duration: 2000
      })
      return;
    }
    var cartid = '';//购物车id
    var cart = this.data.cart;
    for(var i = 0;i < cart.length;i++){
      cartid += cart[i].id+'_';
    }


    wx.request({
      url: app.globalData.datadomain + '/min/Cart/order',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        address_id:address_id,
        cartid:cartid,
        msg:mythis.data.msg

      },
      success: function (res) {
        if (res.data.res.res == 1) {
          wx.navigateTo({
            url: '/pages/pay/pay?total=' + res.data.data.total + '&order_sn=' + res.data.data.order_sn,
          })
         console.log(res)
        } else {
          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })


  },
  //买家留言
  msg:function(e){
   var msg = e.detail.value
   this.setData({msg:msg})
   
  }
})