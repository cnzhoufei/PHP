// page/component/new-pages/cart/cart.js
var app = getApp()
Page({
  data: {
    imgdomain: app.globalData.imgdomain,
    datadomain: app.globalData.datadomain,
    carts:[],               // 购物车列表
    hasList:false,          // 列表是否有数据
    totalPrice:0,           // 总价，初始为0
    selectAllStatus:false    // 全选状态，默认全选
  },
  onShow() {


    if (app.globalData.userInfo) {

      this.setData({
        avatarUrl: app.globalData.userInfo.avatarUrl,
        nickName: app.globalData.userInfo.nickName
      })

      

    } else {
      wx.navigateTo({
        url: '../login/index'
      })
    }

    
    var mythis = this;
    wx.request({
      url: app.globalData.datadomain + '/min/goods/cart', //仅为示例，并非真实的接口地址
      data: {
        store_id: app.globalData.store_id,
        session:app.globalData.session
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        if(res.data.res.res == 1){
          mythis.setData({ carts: res.data.cart, hasList: true })

        }else{
          mythis.setData({ hasList: false })
        }
      }
    });



    this.getTotalPrice();
  },
  /**
   * 当前商品选中事件
   */
  selectList(e) {
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    const selected = carts[index].selected;
    carts[index].selected = !selected;
    this.setData({
      carts: carts
    });
    this.getTotalPrice();
  },

  /**
   * 删除购物车当前商品
   */
  deleteList(e) {
    var mythis = this;
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    wx.request({
      url: app.globalData.datadomain + '/min/goods/deletecart',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        id: e.currentTarget.id,//购物车id
      },
      success: function (res) {
        if (res.data.res.res == 1) {
          wx.showToast({
            title: '' + res.data.res.msg + '',
            duration: 2000
          })
                carts.splice(index, 1);
                mythis.setData({
                  carts: carts
                });
                if (!carts.length) {
                  mythis.setData({
                    hasList: false
                  });
                } else {
                  mythis.getTotalPrice();
                }


        } else {

          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }



      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })





    //--------------------------------------------------------------------------------
             
  },

  /**
   * 购物车全选事件
   */
  selectAll(e) {
    let selectAllStatus = this.data.selectAllStatus;
    selectAllStatus = !selectAllStatus;
    let carts = this.data.carts;

    for (let i = 0; i < carts.length; i++) {
      carts[i].selected = selectAllStatus;
    }
    this.setData({
      selectAllStatus: selectAllStatus,
      carts: carts
    });
    this.getTotalPrice();
  },

  /**
   * 绑定加数量事件
   */
  addCount(e) {
    var mythis = this;
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    let num = carts[index].goods_num;
    num = num + 1;
    wx.request({
      url: app.globalData.datadomain + '/min/goods/cartadd',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        id: carts[index].id
      },
      success: function (res) {
        if (res.data.res.res == 1) {
          carts[index].goods_num = num;
          mythis.setData({
            carts: carts
          });
          mythis.getTotalPrice();
        } else {

          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }



      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })





    
  },

  /**
   * 绑定减数量事件
   */
  minusCount(e) {
    var mythis = this;
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    let num = carts[index].goods_num;
    if(num <= 1){
      return false;
    }
    num = num - 1;


    wx.request({
      url: app.globalData.datadomain + '/min/goods/cartreduction',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        id: carts[index].id
      },
      success: function (res) {
        if (res.data.res.res == 1) {

          carts[index].goods_num = num;
          mythis.setData({
            carts: carts
          });
          mythis.getTotalPrice();
        } else {

          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }



      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })





  },

  /**
   * 计算总价
   */
  getTotalPrice() {
    let carts = this.data.carts;                  // 获取购物车列表
    let total = 0;
    for(let i = 0; i<carts.length; i++) {         // 循环列表得到每个数据
      if(carts[i].selected) {                     // 判断选中才会计算价格
        total += carts[i].goods_num * carts[i].goods_price;   // 所有价格加起来
      }
    }
    this.setData({                                // 最后赋值到data中渲染到页面
      carts: carts,
      totalPrice: total.toFixed(2)
    });
  },
  settlement:function(){
    var strid = '';
    var data = this.data.carts;
    for(var i = 0;i < data.length;i++){
      if (data[i].selected){
        strid += data[i].id+'_'
      }
    }
    console.log(strid)
    if (strid){
      wx.navigateTo({
        url: '/pages/orderdetail/orderdetail?id='+strid
      })
    }else{

      wx.showToast({
        title: '请选择商品！',
        image: '../../images/error.png',
        duration: 2000
      })
    }
   
  }

})