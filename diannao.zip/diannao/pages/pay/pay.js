// pay.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var total = options.total;
    var order_sn = options.order_sn;
    if (!total || !order_sn) { wx.navigateBack(1);}
    var mythis = this;
    mythis.setData({
      total: total,
      order_sn: order_sn,
    })
  
  },
wxpay:function(){


  var mythis = this;
  wx.request({
    url: app.globalData.datadomain + '/Min/Pay/index',
    data: {
      store_id: app.globalData.store_id,
      session: app.globalData.session,
      order_sn:mythis.data.order_sn
    },
    success: function (res) {
      if (res.data.res.res == 1) {
        wx.requestPayment({
          'appId':res.data.data.appId,
          'timeStamp': '' + res.data.data.timeStamp+'',//时间
          'nonceStr': res.data.data.nonceStr,
          'package': res.data.data.package,
          'signType': res.data.data.signType,
          'paySign': res.data.data.paySign,
          'success': function (res) {
            mythis.notifyurl(1)
          },
          'fail': function (res) {
            wx.showToast({
              title: '支付失败!',
              image: '../../images/error.png',
              duration: 2000
            })
            
          }
        })
        
        
      } else {
        wx.showToast({
          title: '' + res.data.res.msg + '',
          image: '../../images/error.png',
          duration: 2000
        })
      }

    }, fail: function () {
      wx.showToast({
        title: '网络请求超时！',
        image: '../../images/error.png',
        duration: 2000
      })
    }
    
  })

  },
  //支付结果处理
  notifyurl: function (n) {
    var mythis = this;
    wx.request({
      url: app.globalData.datadomain + '/Min/Pay/orderstatus',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        order_sn: mythis.data.order_sn,
        pay_status:n
      },
      success: function (res) {
        if (res.data.res.res == 1) {
         
          wx.switchTab({
            url: '/pages/home/home'
          })

        } else {
          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }

    })
  }
})