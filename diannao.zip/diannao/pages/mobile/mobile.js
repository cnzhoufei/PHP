// mobile.js
var app = getApp()
Page({

  data: {
  msg:'获取验证码',
  disabled:true,
  mobile:null
  },
  onLoad:function(){
    wx.request({
      url: app.globalData.datadomain + '/min/Sms/is_setmobile',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
      },
      success: function (res) {
        if (res.data.res.res == 1) {
          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          });
          wx.navigateBack(1);
        }

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })

  },
  formSubmit: function (e) {
    // name
    var name = e.detail.value.name;
    // mobile
    var mobile = e.detail.value.mobile;
    // code
    var code = e.detail.value.code;

    if (name == '') {
      wx.showToast({
        title: '请填写您的姓名', image: '../../images/error.png',
        duration: 2000
      });
      return;
    }
    if (!(/^1[34578]\d{9}$/.test(mobile))) {
      wx.showToast({
        title: '请填写正确手机号码', image: '../../images/error.png',
        duration: 2000
      });
      return;
    }
    if (code == '') {
      wx.showToast({
        title: '验证码不能为空', image: '../../images/error.png',
        duration: 2000
      });
      return;
    }

    if (code != this.data.code) {
      wx.showToast({
        title: '验证码错误！', image: '../../images/error.png',
        duration: 2000
      });
      return;
    }


    wx.request({
      url: app.globalData.datadomain + '/min/Sms/setmobile',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        mobile: mobile,
        name:name,
        code:code
      },
      success: function (res) {
        if (res.data.res.res == 1) {
          wx.showToast({
            title: '' + res.data.res.msg + '',
            duration: 2000
          });
          wx.navigateBack(1);

        } else {
          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })

   
  },
  code:function()
  {
    var i = 60;
    var mythis = this;
    var mobile = this.data.mobile;
    wx.request({
      url: app.globalData.datadomain + '/min/Sms/sendcms',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        mobile:mobile,
      },
      success: function (res) {
        // console.log(res)
        if (res.data.res.res == 1) {
          mythis.setData({
            code:res.data.code,
          })
          var time = setInterval(function () {
            mythis.setData({
              msg: '(' + i + ')秒后重新获取',
              disabled: true
            })
            i--
            if (i <= 0) {
              clearInterval(time)
              mythis.setData({
                msg: '获取验证码',
                disabled: false
              })
            }
          }, 1000)

        }else{
          wx.showToast({
            title: ''+res.data.res.msg+'',
            image: '../../images/error.png',
            duration: 2000
          })
        }

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })
    
   
     
  },
  yanzheng:function(e){
    var mythis = this;
    var mobile = e.detail.value;
    if (!(/^1[34578]\d{9}$/.test(mobile))) {
      wx.showToast({
        title: '请填写正确手机号码', image: '../../images/error.png',
        duration: 2000
      });
      mythis.setData({
        disabled:true
      })
    }else{
      mythis.setData({
        disabled: false,
        mobile:mobile,
      })
    }

  }

})