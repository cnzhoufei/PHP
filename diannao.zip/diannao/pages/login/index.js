//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../home/home'
    })
  },
  //如果是授权同意的或没有授权过的直接执行这里
  onShow: function () {
    var mythis = this;
    wx.getUserInfo({
      withCredentials: false,
      success: function (res) {
        app.globalData.userInfo = res.userInfo
        typeof cb == "function" && cb(app.globalData.userInfo)
        mythis.session()
      }
    })


  },
  //点击登录执行
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.session()
    } else {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        app.globalData.userInfo = res.userInfo
      }
    }
  },
  getUserInfo: function (e) {
    if (e.detail.errMsg == 'getUserInfo:ok'){
      app.globalData.userInfo = e.detail.userInfo
      this.session()
    }else{
      wx.switchTab({
        url: '../home/home'
      })
    }
    
  },
  onindex:function()
  {
    wx.navigateTo({
      url: '/pages/home/home'
    })
  },
  //判断登录是否过期
  session:function(){
 var mythis = this;
    this.login()

                // wx.checkSession({
                //   success: function () {
                //     //session 未过期，并且在本生命周期一直有效
                //     if (!wx.getStorageSync('session')){
                //       mythis.login()
                //     }else{
                //       wx.navigateBack(1);
                //     }
                //   },
                //   fail: function () {
                //     //登录态过期
                //     mythis.login()
                //   }
                // })


  },

  //传值请求openid 存在就登录否则写入数据库
  login:function(){
    wx.login({
      success: function (res) {
        var code = res.code;
        if (res.code) {
          // 发起网络请求
          wx.request({
            url: app.globalData.datadomain+'/min/index/login',
            data: {
              store_id: app.globalData.store_id,
              code: code,//换取openid
              head_pic: app.globalData.userInfo.avatarUrl,//头像
              nickname: app.globalData.userInfo.nickName,//姓名
              sex: app.globalData.userInfo.gender,//性别 0：未知、1：男、2：女
              province: app.globalData.userInfo.province,//省
              city: app.globalData.userInfo.city,//市
              country: app.globalData.userInfo.country,//国
            },
            success: function (res) {
              // console.log(res)
              //缓存转换后台的session
              if(res.data.login.state == 1){
                    //如果后台处理成功 缓存后台传过来的session
                    var session = res.data.login.session;
                    app.globalData.session = session;
                    try {
                      wx.setStorageSync('session', session)
                      
                    } catch (e) {
                    }
              }else{

              }
             
              wx.navigateBack(1);

            }, fail: function () {
              wx.showToast({
                title: '网络请求超时！',
                image: '../../images/error.png',
                duration: 2000
              })
            }
          })

        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    });
  }
})

