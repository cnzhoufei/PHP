// home.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgdomain: app.globalData.imgdomain,
    datadomain: app.globalData.datadomain,
    indicatorDots: false,
    autoplay: true,
    interval: 3000,
    duration: 500,
    nzopen: false,
    shi:null

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var mythis = this;
    wx.chooseAddress({
      success: function (res) {
        // console.log(res.userName)
        // console.log(res.postalCode)
        // console.log(res.provinceName)
        // console.log(res.cityName)
mythis.setData({shi:res.cityName})
        // console.log(res.countyName)
        // console.log(res.detailInfo)
        // console.log(res.nationalCode)
        // console.log(res.telNumber)
      }
    })

    
    wx.request({
      url: app.globalData.datadomain+'/min/index/index/store_id/' +app.globalData.store_id, //仅为示例，并非真实的接口地址
      data: {
       
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        mythis.setData({ indexdata: res.data})
        // console.log(res.data)
      }
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }, 
  
  searchBox: function (e) {
    this.setData({
      nzopen: true
    })
  },
  //产品搜索
  formSubmit: function (e) {
    // console.log('form发生了submit事件，携带数据为：', e.detail.value)
    var str = e.detail.value.name;
  // /min/index/search/store_id/6/str/测试测试
    wx.navigateTo({
      url: '../search/search?search='+str
    })
   



  },
  ongetlocation:function()
  {
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        wx.openLocation({
          latitude: latitude,
          longitude: longitude,
          scale: 28
        })
      }
    })
  }


})