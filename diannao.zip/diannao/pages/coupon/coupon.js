// coupon.js
Page({
  
  data: {
    tabs: ["未使用", "已使用", "已过期"],
    activeIndex: 0,
  },

  tabClick: function (e) {
    this.setData({
      activeIndex: e.currentTarget.id
    });
  },
})