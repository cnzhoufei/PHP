// addresslist.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
  addresslist:null,
  },

  remove: function (e) {
    var id = e.target.id;
    var that = this;
    // 给出确认提示框
    wx.showModal({
      title: '提示',
      content: '确定删除该地址嘛？',
      success:function(res){
        //如果点击了确定按钮 执行删除
            if (res.confirm){
              // 发起网络请求
              wx.request({
                url: app.globalData.datadomain + '/min/Address/delete',
                data: {
                  store_id: app.globalData.store_id,
                  id: id,
                },
                success: function (res) {
                  console.log(res)
                  if(res.data.res == 1){
                    that.onLoad()
                  }else{
                    wx.showToast({
                      title: '删除失败！',
                      image: '../../images/error.png',
                      duration: 2000
                    })
                  }

                 
                }, fail: function () {
                  wx.showToast({
                    title: '网络请求超时！',
                    image: '../../images/error.png',
                    duration: 2000
                  })
                }
              })
            }
      }, 
      fail:function(){
        console.log('没有删除')
      }
      
    })
  },
  onLoad:function()
  {
    var mythis = this;

    wx.request({
      url: app.globalData.datadomain + '/min/Address/addresslist',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
      },
      success: function (res) {
          mythis.setData({addresslist:res.data.addresslist})

      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })
  },
  onShow:function(){
    this.onLoad()


  },
  setdefault:function(e){
    var id = e.target.id;
    var mythis = this;

    wx.request({
      url: app.globalData.datadomain + '/min/Address/setaddress',
      data: {
        store_id: app.globalData.store_id,
        session: app.globalData.session,
        id:id
      },
      success: function (res) {

        if(res.data.res.res == 1){
          mythis.onLoad()
        }else{
          wx.showToast({
            title: '' + res.data.res.msg + '',
            image: '../../images/error.png',
            duration: 2000
          })
        }
       


      }, fail: function () {
        wx.showToast({
          title: '网络请求超时！',
          image: '../../images/error.png',
          duration: 2000
        })
      }
    })
  }

})